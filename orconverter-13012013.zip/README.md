ORConverter
===========

Program to convert orienteering event result lists (IOFdata.dtd 2003) to predefined output formats (cup results)

This software is distributed under the GPLv3 license: http://www.gnu.org/licenses/gpl-3.0.en.html